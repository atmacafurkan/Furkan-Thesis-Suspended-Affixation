var shuffleSequence = seq("intro",
                          sepWith("sep", seq("practice", rshuffle(startsWith("exp"),"filler"))),
                         "send_results",
                         "debrief");
var practiceItemTypes = ["practice", {hideProgressBar: true}];

var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: " ",
        hideProgressBar: true
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: [["q","Evet (Q'ya basınız)"], ["p","Hayır (P'ye basınız)"]],
        q: "Okuduğunuz cümle doğal mı? ",
        presentAsScale: false,
        hideProgressBar: true
    },
    "Question", {
        hideProgressBar: true,
        as: [["q","Evet (Q'ya basınız)"], ["p","Hayır (P'ye basınız)"]],
        hasCorrect: false,
        randomOrder: false,
        autoFirstChar: false,
        showNumbers: false
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

function modifyRunningOrder(ro) {
        for (var i = 0; i < ro.length; ++i) {
            if ( (i != 0) && (i % 40 == 0)) {
                // Passing 'true' as the third argument casues the results from this controller to be omitted from the results file. 
                // (Though in fact, the Message controller does not add any results in any case.)
                ro[i].push(new DynamicElement(
                    "Message",
                    { html: "<p>Kısa bir ara. Bir sonraki cümleye geçmek için boşluk tuşuna basınız.</p>", transfer: "keypress"}, //, transfer: 1000 
                    true
                ));
            }
        }
        return ro;
    }

var items = [

    ["send_results", "__SendResults__", { }],
    
    ["sep", "Separator", { }],

    ["intro", "Form", {
        html: { include: "consent.html" },
        validators: {
            age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],

    ["practice", "AcceptabilityJudgment", {s: "Bu pratik yapmanız için bir cümle."}],
    ["practice", "AcceptabilityJudgment", {s: "Cümleler kulağınıza normal geliyorsa Q'ya, rahatsız edici ise P'ye basın."}],
    ["practice", "AcceptabilityJudgment", {s: "Bu son pratik cümlesi şimdi deney başlıyor!"}],
  
  
    ["debrief", "Message", {
        html: { include: "debrief.html" },
                transfer: 3000  }],
 [["exp_a",1], "AcceptabilityJudgment",{s: "Ahmet herşeyi biliyormuş ve anlıyormuşçasına konuşuyor sağda solda."}],
[["exp_a",2], "AcceptabilityJudgment",{s: "Her şeye rağmen herkesi kabullenir ve severcesine davranmak insanı insan yapar."}],
[["exp_a",3], "AcceptabilityJudgment",{s: "Çok duygulanıp gözlerim yaşarır ve kızarırcasına gülmek istiyorum."}],
[["exp_a",4], "AcceptabilityJudgment",{s: "Sevilmeyen kişiler inat ve yalancı insanlardır."}],
[["exp_a",5], "AcceptabilityJudgment",{s: "Bu devirde insan ve toplumcu davranış sergilemek nadir görülüyor."}],
[["exp_a",6], "AcceptabilityJudgment",{s: "Tartışmalarında duyuduğumuz Trump ve Hillaryci yorumlar tam olarak gerçeği yansıtmıyor."}],
[["exp_a",7], "AcceptabilityJudgment",{s: "Gezegenler listesinden çıkan Pluton gezegen ve göktaşımsı özellikler taşıyor."}],
[["exp_a",8], "AcceptabilityJudgment",{s: "En çok satılan şeker ağızda vanilya ve nanemsi bir tat bırakan."}],
[["exp_a",9], "AcceptabilityJudgment",{s: "Bu tarz olaylar insanın içinde öfke ve nefretimsi duygular doğuruyor."}],
[["exp_a",10], "AcceptabilityJudgment",{s: "Doktora gittiğimizde belimdeki beş ve altıncı kemiklerin zedelendiğini öğrendik."}],
[["exp_a",11], "AcceptabilityJudgment",{s: "Sıraya geçen insanlardan bir ve ikinci sıradakiler aç kalacak."}],
[["exp_a",12], "AcceptabilityJudgment",{s: "Buraya yerleşen göçmenlerin iki ve üçüncü nesilleri Türkçeyi öğrenmiş olacak."}],
[["exp_a",13], "AcceptabilityJudgment",{s: "Buraya ne zaman gelsek vanilya ve çikolatalı dondurmayı mutlaka yeriz."}],
[["exp_a",14], "AcceptabilityJudgment",{s: "Bu saatte pizza söyleyeceksen biber ve sucuklu pizza söyleme lütfen."}],
[["exp_a",15], "AcceptabilityJudgment",{s: "Aldığım elbisenin üzerinde nokta ve çizgili motifler varsa ayakkabı bulmak zor olur."}],
[["exp_a",16], "AcceptabilityJudgment",{s: "Bu yasa tasarısı tartışma ve itirazsız kabul edilmiş mecliste."}],
[["exp_a",17], "AcceptabilityJudgment",{s: "İnsanların dayanabileceği su ve yemeksiz gün sayısı belli."}],
[["exp_a",18], "AcceptabilityJudgment",{s: "Seksenlerde başlayan yağ ve şekersiz yiyecekler tüketme trendi çok uzun sürmedi."}],
[["exp_a",19], "AcceptabilityJudgment",{s: "Sabah okul zili çalınca öğrenciler üç ve dörder sıraya dizilirler."}],
[["exp_a",20], "AcceptabilityJudgment",{s: "Bu mağaza pantolonları beş ve altışar raflara diziyor."}],
[["exp_a",21], "AcceptabilityJudgment",{s: "Masa bacaklarını yedi ve sekizer paketler halinde saklıyoruz."}],
[["exp_a",22], "AcceptabilityJudgment",{s: "Aslına bakılırsa kalem ve defteri çok pahalıya almışsın."}],
[["exp_a",23], "AcceptabilityJudgment",{s: "Yarın köyden gelecek turşu ve ezmeyi hemen yeyip bitirmezsem iyi olur."}],
[["exp_a",24], "AcceptabilityJudgment",{s: "Geç saatlerde yürüdğüm yol ve sahili hiç unutmadım."}],
[["exp_a",25], "AcceptabilityJudgment",{s: "Bu yarışta Alman ekibi ikinci ve üçüncülük kupasını kıl payı kaçırdı."}],
[["exp_a",26], "AcceptabilityJudgment",{s: "Başkalarına karşı beslediğimiz dost ve düşmanlık hisleri bizi mutlaka etkiliyordur."}],
[["exp_a",27], "AcceptabilityJudgment",{s: "Pazara gidip beş kilo ve altı kiloluk paketler halinde patates alıp geldim."}],
[["exp_b",1], "AcceptabilityJudgment",{s: "Ahmet herşeyi biliyormuş veya anlıyormuşçasına konuşuyor sağda solda."}],
[["exp_b",2], "AcceptabilityJudgment",{s: "Her şeye rağmen herkesi kabullenir veya severcesine davranmak insanı insan yapar."}],
[["exp_b",3], "AcceptabilityJudgment",{s: "Çok duygulanıp gözlerim yaşarır veya kızarırcasına gülmek istiyorum."}],
[["exp_b",4], "AcceptabilityJudgment",{s: "Sevilmeyen kişiler inat veya kırıcı insanlardır."}],
[["exp_b",5], "AcceptabilityJudgment",{s: "Bu devirde insan veya toplumcu davranış sergilemek nadir görülüyor."}],
[["exp_b",6], "AcceptabilityJudgment",{s: "Tartışmalarında duyuduğumuz Trump veya Hillaryci yorumlar tam olarak gerçeği yansıtmıyor."}],
[["exp_b",7], "AcceptabilityJudgment",{s: "Gezegenler listesinden çıkan Pluton gezegen veya göktaşımsı özellikler taşıyor."}],
[["exp_b",8], "AcceptabilityJudgment",{s: "En çok satılan şeker ağızda vanilya veya nanemsi bir tat bırakan."}],
[["exp_b",9], "AcceptabilityJudgment",{s: "Bu tarz olaylar insanın içinde öfke veya nefretimsi duygular doğuruyor."}],
[["exp_b",10], "AcceptabilityJudgment",{s: "Doktora gittiğimizde belimdeki beş veya altıncı kemiklerin zedelendiğini öğrendik."}],
[["exp_b",11], "AcceptabilityJudgment",{s: "Sıraya geçen insanlardan bir veya ikinci sıradakiler aç kalacak."}],
[["exp_b",12], "AcceptabilityJudgment",{s: "Buraya yerleşen göçmenlerin iki veya üçüncü nesilleri Türkçeyi öğrenmiş olacak."}],
[["exp_b",13], "AcceptabilityJudgment",{s: "Buraya ne zaman gelsek vanilya veya çikolatalı dondurmayı mutlaka yeriz."}],
[["exp_b",14], "AcceptabilityJudgment",{s: "Bu saatte pizza söyleyeceksen biber veya sucuklu pizza söyleme lütfen."}],
[["exp_b",15], "AcceptabilityJudgment",{s: "Aldığım elbisenin üzerinde nokta veya çizgili motifler varsa ayakkabı bulmak zor olur."}],
[["exp_b",16], "AcceptabilityJudgment",{s: "Bu yasa tasarısı tartışma veya itirazsız kabul edilmiş mecliste."}],
[["exp_b",17], "AcceptabilityJudgment",{s: "İnsanların dayanabileceği su veya yemeksiz gün sayısı belli."}],
[["exp_b",18], "AcceptabilityJudgment",{s: "Seksenlerde başlayan yağ veya şekersiz yiyecekler tüketme trendi çok uzun sürmedi."}],
[["exp_b",19], "AcceptabilityJudgment",{s: "Sabah okul zili çalınca öğrenciler üç veya dörder sıraya dizilirler."}],
[["exp_b",20], "AcceptabilityJudgment",{s: "Bu mağaza pantolonları beş veya altışar raflara diziyor."}],
[["exp_b",21], "AcceptabilityJudgment",{s: "Masa bacaklarını yedi veya sekizer paketler halinde saklıyoruz."}],
[["exp_b",22], "AcceptabilityJudgment",{s: "Aslına bakılırsa kalem veya defteri çok pahalıya almışsın."}],
[["exp_b",23], "AcceptabilityJudgment",{s: "Yarın köyden gelecek turşu veya ezmeyi hemen yeyip bitirmezsem iyi olur."}],
[["exp_b",24], "AcceptabilityJudgment",{s: "Geç saatlerde yürüdğüm yol veya sahili hiç unutmadım."}],
[["exp_b",25], "AcceptabilityJudgment",{s: "Bu yarışta Alman ekibi ikinci veya üçüncülük kupasını kıl payı kaçırdı."}],
[["exp_b",26], "AcceptabilityJudgment",{s: "Başkalarına karşı beslediğimiz dost veya düşmanlık hisleri bizi mutlaka etkiliyordur."}],
[["exp_b",27], "AcceptabilityJudgment",{s: "Pazara gidip beş kilo veya altı kiloluk paketler halinde patates alıp geldim."}],
[["filler",101], "AcceptabilityJudgment",{s: "Öğretmenler odasından yükselen sesler bazı öğrencileri endişelendirdi."}],
[["filler",102], "AcceptabilityJudgment",{s: "Sayfalarını kurcaladığı kitabı bir kenara koyulup yazmaya devam etti."}],
[["filler",103], "AcceptabilityJudgment",{s: "Eğer uzlaşma sağlanırsa Suriyede yeni anyasa oluşturma sürecine geçilecek."}],
[["filler",104], "AcceptabilityJudgment",{s: "Her gün çekiçle ve kazmayla çalıştığına elleri bir hayli nasırlıydı."}],
[["filler",105], "AcceptabilityJudgment",{s: "Devlet tiyatrolarının salonları sezon boyunca doluyor ve bilet bulmak çok zor."}],
[["filler",106], "AcceptabilityJudgment",{s: "Bu çiçek kırılgan ve narin bir yapıya sahip o yüzden yetiştirilmek çok zor."}],
[["filler",107], "AcceptabilityJudgment",{s: "Amasra'ya giderken bir süre ağaçlarla çevrili bir yoldan geçersiniz."}],
[["filler",108], "AcceptabilityJudgment",{s: "Elektrikli araç üretimi son yıllardaki en yüksek seviyesinde ve hala artılmakta."}],
[["filler",109], "AcceptabilityJudgment",{s: "Gıda zehirlenmesi yaşayan askerler acilen hastaneye kaldırılıp tedavi altına alınacak."}],
[["filler",110], "AcceptabilityJudgment",{s: "Hareketlerinde bir sorun göremeyen dansçı hocasına sitem olduruyor."}],
[["filler",111], "AcceptabilityJudgment",{s: "Müziğe kendini kaptıran seyirciler hep bir ağızdan sözleri tekrar ediyorlar."}],
[["filler",112], "AcceptabilityJudgment",{s: "Katıldığı bir programda kendisine yöneltilen soruyu saçma denip geçiştirdi."}],
[["filler",113], "AcceptabilityJudgment",{s: "Hong Kong bu aralar göstericiler ve polis arasındaki çatışmalara şahit oluyor."}],
[["filler",114], "AcceptabilityJudgment",{s: "Ağır kayıplar veren ittifak devletleri savaşta yeni bir cephe açtırılmak istiyorlar."}],
[["filler",115], "AcceptabilityJudgment",{s: "Kaş göz hareketi yaparak garsona sürpriz pastayı getirmesini işaret etti."}],
[["filler",116], "AcceptabilityJudgment",{s: "Masasının gizli bölmesinde her ihtimalde karşı bir silah bulunduruyordu."}],
[["filler",117], "AcceptabilityJudgment",{s: "İki Şehrin Hikayesi hak ettiği gibi MEB ilk yüz eser listesinde yer almaktadır."}],
[["filler",118], "AcceptabilityJudgment",{s: "Berberler birçok kültürde kilit olmasa da önemli bir rol oynanmaktadır."}],
[["filler",119], "AcceptabilityJudgment",{s: "Hristiyan demokratların Almanya ve Avrupa birliğindeki başarısını biliyoruz."}],
[["filler",120], "AcceptabilityJudgment",{s: "Birçok kez anayasa değişikliği gidilen Türkiye referandumlara yabancı değil."}],
[["filler",121], "AcceptabilityJudgment",{s: "Hiç değilse yaşadığını biliyorsun, bu bile yeter bazen insana."}],
[["filler",122], "AcceptabilityJudgment",{s: "Kimyasal sızıntı nedeniyle fabrika acilen tahliye oldurulmak zorundaydı."}],
[["filler",123], "AcceptabilityJudgment",{s: "Dolapta bulduğu birkaç malzemeyle kendisine kahvaltı hazırlayıp yedi."}],
[["filler",124], "AcceptabilityJudgment",{s: "Eski Türk filmlerinden fırlama çizgili bir pijaması vardı ve ona giyinip uyurdu."}],
[["filler",125], "AcceptabilityJudgment",{s: "Günlük doldurması gereken belgeleri birike birike bir yığın haline gelmişti."}],
[["filler",126], "AcceptabilityJudgment",{s: "Yapımı devam eden projeyi mali yetersizliklere dolayı sonlandırdı."}],
[["filler",127], "AcceptabilityJudgment",{s: "Yeni aldığı traktörü bir hevesle çalıştırıp tarlasına doğru yol aldı."}],
[["filler",128], "AcceptabilityJudgment",{s: "Planları istediği gibi giderse ona güvenilen herkes memnun olacak."}],
[["filler",129], "AcceptabilityJudgment",{s: "Bekarlar partisi düzenlemek isteyen damada gelin izin vermedi."}],
[["filler",130], "AcceptabilityJudgment",{s: "Kaynağı belli olmayan bilgilere göre birçok kişinin evi izlendirilmiş."}],
[["filler",131], "AcceptabilityJudgment",{s: "Yöre insanının her sene düzenlediği festivale bu sene büyük isimler de katılıyor."}],
[["filler",132], "AcceptabilityJudgment",{s: "Haber ajanslarından alınan bilgiye göre yangına zamanında müdahale olunulmamış."}],
[["filler",133], "AcceptabilityJudgment",{s: "Diğer milletler tarafından kabul görmeyen gruplar marjinalleşmeye eğilimlidir."}],
[["filler",134], "AcceptabilityJudgment",{s: "Yapılan değişikliklere karşı gelinmek anlaşılabilir ancak kabul edilemez."}],
[["filler",135], "AcceptabilityJudgment",{s: "Çocuklar top oynarken hiç kimseyi ve hiçbir şeyi duymuyorlar ki."}],
[["filler",136], "AcceptabilityJudgment",{s: "Su ve hava kirliliği ile mücadele konusunda belediye sınıfta kalınmış durumda."}],
[["filler",137], "AcceptabilityJudgment",{s: "Öğrenciler için sağlanan aylık kart imkanı herkes tarafından olumlu karşılandı."}],
[["filler",138], "AcceptabilityJudgment",{s: "Sınır ihlallerine karşılık verinmek her ülkenin özgün hakkı ve ayrıcalığıdır."}],
[["filler",139], "AcceptabilityJudgment",{s: "İç savaştan kaçan göçmenlerin yığıldığı şehirler hizmet vermekte zorlanıyor."}],
[["filler",140], "AcceptabilityJudgment",{s: "Son on yıldaki ağaçlandırma faaliyetleri meyvelerine vermeye başladı bile."}],
[["filler",141], "AcceptabilityJudgment",{s: "Dünya genelinde kabul gören Birleşmiş Milletler birçok sorumluluk üstlenmektedir."}],
[["filler",142], "AcceptabilityJudgment",{s: "Madde kullanımına mücadele kolluk kuvvetlerinden sosyal hizmetlere kaydırılmalı."}],
[["filler",143], "AcceptabilityJudgment",{s: "Eskinin taş plak şarkıları günümüzde dijital ortamda daha iyi muhafaza ediliyor."}],
[["filler",144], "AcceptabilityJudgment",{s: "Müzik ve sanata olan merakı onda her zaman hobi olarak kalınmış ve ilerlememiştir."}],
[["filler",145], "AcceptabilityJudgment",{s: "Ders başlamadan önce sınıf defterini dolduran öğretmen bir yandan yoklama aldı."}],
[["filler",146], "AcceptabilityJudgment",{s: "Takviminde boş kalan günleri kendine hediye saydırılan çok yoğun bir insandı."}],
[["filler",147], "AcceptabilityJudgment",{s: "Vakit buldukça arkadaşlarıyla dolaşıp vakit öldürüyordu aklı sıra."}],
[["filler",148], "AcceptabilityJudgment",{s: "İzleyenlerin hayal dünyasını genişleten filmler listesi oluşturunmak lazım."}],
[["filler",149], "AcceptabilityJudgment",{s: "Özenle her gün yazdığı günlüğünü seneler sonra bulup sevinmişti kadın."}],
[["filler",150], "AcceptabilityJudgment",{s: "Kardeşlerinin ayakkabılarına götürüp çamura atan yaramaz çocuk buydu."}],
[["filler",151], "AcceptabilityJudgment",{s: "Yaptıklarımı dikkatlice izlerseniz püf noktasının ne olduğunu anlarsınız."}],
[["filler",152], "AcceptabilityJudgment",{s: "Geride bıraktığı ailesi ve anılarını birkaç ay sonra unutulup yeni bir hayata başladı."}],
[["filler",153], "AcceptabilityJudgment",{s: "Mesleğe ilk atıldığında çırak olan Mehmet artık bir marangoz ustası olmuştu."}],
[["filler",154], "AcceptabilityJudgment",{s: "Yaklaşan oğlunun sesini duyunca uzağı göremeyen gözleri yaşarınmıştı birden."}]
];







